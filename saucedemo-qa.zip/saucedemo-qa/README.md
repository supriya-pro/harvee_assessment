# Sauce Demo – Shop and Check Out (QA Automation)

Manual suite (A1) in [`docs/MANUAL_TESTS.md`](docs/MANUAL_TESTS.md). Automated suite (A2) in this repo: Java 17, Selenium 4, TestNG, Maven, Page Object Model. Target: https://www.saucedemo.com only.

## Setup

- JDK 17+ and Maven 3.9+
- Chrome (default), Firefox or Edge installed. Selenium Manager downloads the matching driver automatically.

## Run

```bash
mvn test                                   # headless Chrome, default config
mvn test -Dheadless=false                  # watch the browser
mvn test -Dbrowser=firefox                 # chrome | firefox | edge
mvn test -Dtest=CheckoutTests              # one class
BASE_URL=https://www.saucedemo.com PASSWORD=secret_sauce mvn test
```

Settings come from `-D` properties, then environment variables (`BASE_URL`, `BROWSER`, `HEADLESS`, `STANDARD_USER`, `LOCKED_USER`, `PASSWORD`), then `src/test/resources/config.properties`.

## Reports and evidence

- HTML report: `target/surefire-reports/index.html`
- JUnit XML: `target/surefire-reports/*.xml`
- Failure screenshots: `target/screenshots/<test name>.png` (saved by `TestListener`)

## Structure

```
src/test/java/com/harvee/qa/
  pages/     page objects (all locators live here)
  support/   Config, DriverManager, TestListener (screenshots)
  tests/     test classes; method and description start with the manual case ID
```

Design rules: no locators in tests; no `Thread.sleep` and no implicit wait, only explicit waits in `BasePage`; every test starts its own browser, logs in itself and never depends on another test, so any order works.

## Traceability: manual case to automated test

| Manual case | Automated test | Notes |
|---|---|---|
| TC01 | `LoginTests.tc01_standardUserLogsIn` | |
| TC02 | `LoginTests.tc02_lockedOutUserIsRejected` | |
| TC03 | `LoginTests.tc03_tc04_invalidLoginsAreRejected` | data row "wrong password" |
| TC04 | `LoginTests.tc03_tc04_invalidLoginsAreRejected` | data row "empty fields" |
| TC05 | `SortingTests.tc05_sortsByPriceLowToHigh` | checks all 6 prices |
| TC06 | `SortingTests.tc06_sortsByPriceHighToLow` | |
| TC07 | `SortingTests.tc07_sortsByName` | A-Z and Z-A |
| TC08 | `CartTests.tc08_addTwoItemsAndRemoveOne` | badge and cart contents |
| TC09 | `CartTests.tc09_removeItemFromCartPage` | |
| TC10 | `CartTests.tc10_badgeHiddenWhenCartEmpty` | |
| TC11 | manual only | low value, covered by TC08 |
| TC12 | `CheckoutTests.tc12_fullCheckoutWithCorrectTotals` | total = item total + tax; cart empty after |
| TC13 | `CheckoutTests.tc13_tc14_tc15_missingCheckoutFieldsShowErrors` | parameterized |
| TC14 | `CheckoutTests.tc13_tc14_tc15_missingCheckoutFieldsShowErrors` | parameterized |
| TC15 | `CheckoutTests.tc13_tc14_tc15_missingCheckoutFieldsShowErrors` | parameterized |
| TC16 | manual only | needs judgement (open question Q2) |
| TC17 | `CheckoutTests.tc17_cancelKeepsCartAndPlacesNoOrder` | |
| TC18 | manual only | depends on unanswered Q1 |
| TC19 | `AccessControlTests.tc19_productsPageByUrlAfterLogout` | |
| TC20 | `AccessControlTests.tc20_checkoutPageByUrlWhenLoggedOut` | |
| TC21 | manual only | usability judgement |
| TC22 | manual only | keyboard and screen-reader check; axe scan as a separate job |
| TC23 | manual only | cross-browser/mobile matrix, later via grid |
| TC24 | manual only | timing varies, tracked manually |

17 of 24 manual cases are automated across 14 test methods (the two parameterized methods run 5 data rows).

## Assumptions

- Shared password and user names are the public ones on the login page; they sit in config, not in tests.
- Tax is not hard-coded: the test checks total = item total + tax and that tax is greater than zero (open question Q4).
- The suite has not been run against the live site from the authoring environment (outbound access to the site was not available); first thing to do is run `mvn test` and fix any locator drift.

## Growing to 200 tests

Split by feature into packages with one page object per page and shared components (header, cart badge, menu) extracted as component classes. Add tags (`smoke`, `regression`) and run smoke on every pull request, full regression nightly. Run tests in parallel with TestNG `parallel="methods"`; the ThreadLocal driver and per-test browsers already allow this. Move setup to faster routes: log in through a saved session cookie and move pricing, tax and sorting checks to API or unit level so the UI layer stays small. Move test data to builders or JSON files, run Chrome, Firefox and Edge in a Selenium Grid or cloud grid in CI, track flaky tests with retry-and-report (never silent retries), and keep the manual-to-automated table generated from test annotations.
