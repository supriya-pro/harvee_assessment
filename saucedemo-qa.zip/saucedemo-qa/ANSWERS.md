# Section B – AI output and client communication

## B1. Review of the AI-generated cart total test

### Problems found

1. **The assertion proves nothing.** `expect(total).toBeTruthy()` passes for any non-empty text, including "Total: $0.00" or a wrong amount. The test name says "is correct" but nothing is checked for correctness.
2. **Fixed sleep.** `waitForTimeout(3000)` slows every run by 3 seconds and still does not guarantee readiness. Playwright already waits for elements before acting.
3. **Ambiguous locator.** `text=Add to cart` matches six buttons; it silently clicks the first, so the test depends on product order and breaks if sorting or the catalogue changes. The test never says which item it expects.
4. **Fragile locators.** A mix of `#id`, `.shopping_cart_link` (styling class) and `.summary_total_label` (styling class). Prefer the stable `data-test` attributes or role-based locators.
5. **Hard-coded URL, user and password** in the test body. They belong in config or environment variables so the test runs against other environments and secrets stay out of the repository.
6. **No check that login or navigation worked.** If login fails, the later steps fail with confusing errors. There is no check of the cart badge, the cart contents or the page URL.
7. **Wrong data parsed.** `textContent()` returns text like "Total: $32.39", which is a string with a label, not a number. Nothing compares item total + tax with total.
8. **No tax or item total check.** The business rule (total = item total + tax) is the point of the test and is not covered; the expected value is not derived from the displayed item price either.
9. **Poor test data.** Names "A", "B" and postal code "1" are throwaway values with no meaning for the reader.
10. **No structure.** Login and checkout steps are repeated inline, so every future test copies them. A page object or fixture is needed.
11. **Floating point risk.** If amounts are parsed as `float`, sums such as 29.99 + 2.40 can mismatch by a fraction of a cent. Compare in cents.
12. **Unverified AI output.** The test has not been shown to fail when the app is wrong. Before merging, break the expected value once (a mutation check) and confirm the test goes red.

### Rewrite (Playwright, TypeScript)

```ts
import { test, expect, Page } from '@playwright/test';

const BASE_URL = process.env.BASE_URL ?? 'https://www.saucedemo.com';
const USER = process.env.STANDARD_USER ?? 'standard_user';
const PASSWORD = process.env.PASSWORD ?? 'secret_sauce';

// "$12.34" or "Total: $12.34" -> 1234 (cents, avoids floating point errors)
const toCents = (text: string): number => {
  const match = text.match(/\$(\d+)\.(\d{2})/);
  if (!match) throw new Error(`No amount found in "${text}"`);
  return Number(match[1]) * 100 + Number(match[2]);
};

async function login(page: Page) {
  await page.goto(BASE_URL);
  await page.getByTestId('username').fill(USER);
  await page.getByTestId('password').fill(PASSWORD);
  await page.getByTestId('login-button').click();
  await expect(page).toHaveURL(/inventory\.html/);
}

test.use({ testIdAttribute: 'data-test' });

test('TC12 cart total equals item total plus tax', async ({ page }) => {
  await login(page);

  // Add two named items and read their listed prices
  const items = ['Sauce Labs Backpack', 'Sauce Labs Bike Light'];
  let expectedItemTotal = 0;
  for (const name of items) {
    const card = page.getByTestId('inventory-item').filter({ hasText: name });
    expectedItemTotal += toCents(await card.getByTestId('inventory-item-price').innerText());
    await card.getByRole('button', { name: 'Add to cart' }).click();
  }
  await expect(page.getByTestId('shopping-cart-badge')).toHaveText('2');

  await page.getByTestId('shopping-cart-link').click();
  await expect(page.getByTestId('inventory-item')).toHaveCount(2);
  await page.getByTestId('checkout').click();

  await page.getByTestId('firstName').fill('Ada');
  await page.getByTestId('lastName').fill('Lovelace');
  await page.getByTestId('postalCode').fill('12345');
  await page.getByTestId('continue').click();

  const itemTotal = toCents(await page.getByTestId('subtotal-label').innerText());
  const tax = toCents(await page.getByTestId('tax-label').innerText());
  const total = toCents(await page.getByTestId('total-label').innerText());

  expect(itemTotal, 'item total matches the prices on the products page').toBe(expectedItemTotal);
  expect(tax, 'tax is charged').toBeGreaterThan(0);
  expect(total, 'total = item total + tax').toBe(itemTotal + tax);
});
```

Before merging I would also change `toBe(itemTotal + tax)` to `+ 1` once to confirm the test fails, then change it back.

---

## B2. Test an AI feature – Test case generator

Four checks for the evaluation set. The set is 30 to 50 user stories of mixed quality, each with a reviewed reference list of required scenarios and requirements.

| # | Check | How it is built | Scoring |
|---|-------|-----------------|---------|
| 1 | **Output format is valid every time.** Output parses as JSON, matches the schema (required fields, allowed enum values for priority and type, steps as array), and imports into the test management tool without error. | Run each story 5 times, including stories with odd characters, very long text and quotes. Validate with a JSON Schema and a dry-run import. | **Automatic.** Pass/fail per run; target 100 percent. Any failure blocks release because the import is direct. |
| 2 | **Coverage.** The cases cover the reference scenarios (positive, negative, boundary, permissions) for the story. | Each story has a checklist of required scenarios written by a senior tester. A judge (script or second LLM) maps each generated case to checklist items. | **Rubric.** Coverage percent per story, plus a minimum for negative and boundary cases; a tester spot-checks 20 percent of the judge's mappings to keep it honest. |
| 3 | **No invented requirements.** Every expected result and rule is traceable to the story text, with no made-up fields, limits or behaviours. | Include stories that are deliberately vague (no stated password length, no limits). Flag any case that states a number, message or rule absent from the story. | **Human review** on the full set at release, **rubric-assisted LLM judge** for regression runs. Count of unsupported claims per story; target zero on vague stories (it should ask or mark an assumption). |
| 4 | **Duplicates and quality.** No two cases test the same thing; titles, steps and expected results are specific and runnable. | Compute similarity between cases in one output (embedding or normalised text); also run the same story twice and compare. | **Automatic** for duplicate rate above a similarity threshold, **human review** of borderline pairs. Target below 5 percent duplicates. |

---

## B3. Defect report (Jira)

**Title:** Product sort "Price (low to high)" returns items in wrong order ($29.99 shown before $15.99) – regression in 4.2.0

**Project / Type / Component:** Shop / Bug / Products page – Sorting
**Affects version:** 4.2.0 **Regression:** Yes, per team note it did not occur before 4.2.0 (to confirm against 4.1.x)
**Reproducibility:** 100 percent, every run since 4.2.0
**Environment:** Release 4.2.0, test environment [URL], Chrome [version, e.g. latest stable] on [OS], window 1280×900, user `standard_user`

**Steps to reproduce**
1. Open the application in Chrome and log in as `standard_user`.
2. On the Products page, open the sort dropdown (top right).
3. Select "Price (low to high)".
4. Read the prices of the listed items from top to bottom.

**Expected result:** All items are in ascending price order, so $15.99 appears before $29.99.

**Actual result:** An item priced $29.99 appears before an item priced $15.99. The list is not in ascending price order.

**Severity: Major (S2).** Reason: a core browsing function returns wrong results on every attempt and customers comparing prices will notice. It is not Critical because no order, payment or data is lost and the user can still shop (sort by name, or scan the list). Suggested priority: High, fix before release because the regression is visible and affects trust.

**Additional information:** Check whether "Price (high to low)", name sorting, other browsers and other users are affected; the automated test TC05 (whole-list price check) fails. Possible cause: prices compared as text or sort comparator changed in 4.2.0.

**Evidence to attach**
- Screenshot of the sorted list with the two prices visible
- Short screen recording of the steps
- Automated test report and failure screenshot for TC05
- Browser console log and network/HAR file for the page load
- List of prices in displayed order (copied from the DOM)
- Comparison result from 4.1.x showing correct order, if that build is available

---

## B4. Message to the product manager

> Hi [Name], here is where testing stands for Friday.
>
> Two issues: (1) Sorting by "Price (low to high)" is wrong. A $29.99 item shows before a $15.99 item, which customers will notice. (2) Our checkout test failed in about 1 of 10 runs. We don't yet know if it's a test glitch or a real risk to orders.
>
> My recommendation: don't release as planned on Friday morning. If the team fixes sorting tomorrow, we'll retest it and run checkout 50 times by 2 pm. If both are clean, you can release Friday afternoon.
>
> If the fix isn't ready, a fallback is releasing with price sorting switched off; the rest is ready.
>
> Can we have a 10-minute call at 10 am to decide?
