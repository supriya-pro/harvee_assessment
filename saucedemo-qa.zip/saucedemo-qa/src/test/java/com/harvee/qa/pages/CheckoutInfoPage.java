package com.harvee.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/** Checkout step one: customer information. */
public class CheckoutInfoPage extends BasePage {

    public static final String PATH = "/checkout-step-one.html";

    private static final By FIRST_NAME = By.id("first-name");
    private static final By LAST_NAME = By.id("last-name");
    private static final By POSTAL_CODE = By.id("postal-code");
    private static final By CONTINUE = By.id("continue");
    private static final By ERROR = By.cssSelector("[data-test='error']");

    public CheckoutInfoPage(WebDriver driver) {
        super(driver);
    }

    public CheckoutInfoPage waitUntilLoaded() {
        visible(FIRST_NAME);
        waitForPath(PATH);
        return this;
    }

    public CheckoutInfoPage openDirectly(String baseUrl) {
        driver.get(baseUrl + PATH);
        return this;
    }

    public CheckoutInfoPage fill(String first, String last, String postal) {
        type(FIRST_NAME, first);
        type(LAST_NAME, last);
        type(POSTAL_CODE, postal);
        return this;
    }

    public CheckoutOverviewPage continueToOverview() {
        click(CONTINUE);
        return new CheckoutOverviewPage(driver).waitUntilLoaded();
    }

    /** Clicks Continue expecting validation to stop the user on this page. */
    public CheckoutInfoPage continueExpectingError() {
        click(CONTINUE);
        visible(ERROR);
        return this;
    }

    public String errorMessage() {
        return text(ERROR);
    }
}
