package com.harvee.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.stream.Collectors;

public class CartPage extends BasePage {

    public static final String PATH = "/cart.html";

    private static final By TITLE = By.cssSelector("[data-test='title']");
    private static final By ITEM_NAME = By.cssSelector("[data-test='inventory-item-name']");
    private static final By CHECKOUT = By.id("checkout");
    private static final By CONTINUE_SHOPPING = By.id("continue-shopping");
    private static final By CART_BADGE = By.cssSelector("[data-test='shopping-cart-badge']");

    public CartPage(WebDriver driver) {
        super(driver);
    }

    public CartPage waitUntilLoaded() {
        visible(TITLE);
        waitForPath(PATH);
        return this;
    }

    public List<String> itemNames() {
        return all(ITEM_NAME).stream().map(WebElement::getText).collect(Collectors.toList());
    }

    public CartPage remove(String itemName) {
        By remove = By.id("remove-" + itemName.toLowerCase().replace(' ', '-'));
        click(remove);
        wait.until(d -> !itemNames().contains(itemName));
        return this;
    }

    public int cartBadgeCount() {
        List<WebElement> badge = all(CART_BADGE);
        return badge.isEmpty() ? 0 : Integer.parseInt(badge.get(0).getText());
    }

    public CheckoutInfoPage checkout() {
        click(CHECKOUT);
        return new CheckoutInfoPage(driver).waitUntilLoaded();
    }

    public InventoryPage continueShopping() {
        click(CONTINUE_SHOPPING);
        return new InventoryPage(driver).waitUntilLoaded();
    }
}
