package com.harvee.qa.tests;

import com.harvee.qa.pages.CheckoutInfoPage;
import com.harvee.qa.pages.InventoryPage;
import com.harvee.qa.pages.LoginPage;
import com.harvee.qa.support.Config;
import org.testng.Assert;
import org.testng.annotations.Test;

public class AccessControlTests extends BaseTest {

    @Test(description = "TC19 products page cannot be opened by URL after logout")
    public void tc19_productsPageByUrlAfterLogout() {
        InventoryPage inventory = loginAsStandardUser();
        LoginPage login = inventory.logout();

        inventory.openDirectly();

        Assert.assertTrue(login.isDisplayed(), "Login page should be shown");
        Assert.assertEquals(login.currentPath(), "/", "User must be sent back to the login page");
        Assert.assertTrue(login.errorMessage().contains("logged in"),
                "Error should explain login is needed, but was: " + login.errorMessage());
    }

    @Test(description = "TC20 checkout page cannot be opened by URL when logged out")
    public void tc20_checkoutPageByUrlWhenLoggedOut() {
        LoginPage login = openLoginPage();

        new CheckoutInfoPage(driver).openDirectly(Config.baseUrl());

        Assert.assertTrue(login.isDisplayed(), "Login page should be shown");
        Assert.assertEquals(login.currentPath(), "/");
        Assert.assertTrue(login.errorMessage().contains("logged in"),
                "Unexpected message: " + login.errorMessage());
    }
}
