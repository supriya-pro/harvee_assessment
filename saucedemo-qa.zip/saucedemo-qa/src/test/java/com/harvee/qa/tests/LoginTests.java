package com.harvee.qa.tests;

import com.harvee.qa.pages.InventoryPage;
import com.harvee.qa.pages.LoginPage;
import com.harvee.qa.support.Config;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class LoginTests extends BaseTest {

    @Test(description = "TC01 standard user logs in and sees the products page")
    public void tc01_standardUserLogsIn() {
        InventoryPage inventory = loginAsStandardUser();

        Assert.assertEquals(inventory.title(), "Products");
        Assert.assertEquals(inventory.itemCount(), 6, "Number of products shown");
    }

    @Test(description = "TC02 locked-out user sees a locked-out error and stays on the login page")
    public void tc02_lockedOutUserIsRejected() {
        LoginPage login = openLoginPage().submit(Config.lockedUser(), Config.password());

        Assert.assertTrue(login.errorMessage().contains("locked out"),
                "Error should say the user is locked out, but was: " + login.errorMessage());
        Assert.assertTrue(login.isDisplayed(), "User should still be on the login page");
        Assert.assertEquals(login.currentPath(), "/");
    }

    @DataProvider(name = "invalidLogins")
    public Object[][] invalidLogins() {
        return new Object[][]{
                {"TC03 wrong password", Config.standardUser(), "wrong_password", "do not match"},
                {"TC04 empty fields", "", "", "Username is required"}
        };
    }

    @Test(dataProvider = "invalidLogins", description = "TC03/TC04 invalid logins are rejected with a clear message")
    public void tc03_tc04_invalidLoginsAreRejected(String caseName, String user, String password, String expectedPart) {
        LoginPage login = openLoginPage();
        if (user.isEmpty() && password.isEmpty()) {
            login.submitEmpty();
        } else {
            login.submit(user, password);
        }

        Assert.assertTrue(login.errorMessage().contains(expectedPart),
                caseName + ": unexpected error: " + login.errorMessage());
        Assert.assertTrue(login.isDisplayed());
    }
}
