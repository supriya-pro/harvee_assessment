package com.harvee.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.math.BigDecimal;

/** Checkout step two: overview with item total, tax and total. */
public class CheckoutOverviewPage extends BasePage {

    public static final String PATH = "/checkout-step-two.html";

    private static final By SUBTOTAL = By.cssSelector("[data-test='subtotal-label']");
    private static final By TAX = By.cssSelector("[data-test='tax-label']");
    private static final By TOTAL = By.cssSelector("[data-test='total-label']");
    private static final By FINISH = By.id("finish");
    private static final By CANCEL = By.id("cancel");

    public CheckoutOverviewPage(WebDriver driver) {
        super(driver);
    }

    public CheckoutOverviewPage waitUntilLoaded() {
        visible(FINISH);
        waitForPath(PATH);
        return this;
    }

    private BigDecimal amount(By locator) {
        String text = text(locator);
        // Labels look like "Item total: $39.98", "Tax: $3.20", "Total: $43.18"
        return new BigDecimal(text.substring(text.indexOf('$') + 1).trim());
    }

    public BigDecimal itemTotal() {
        return amount(SUBTOTAL);
    }

    public BigDecimal tax() {
        return amount(TAX);
    }

    public BigDecimal total() {
        return amount(TOTAL);
    }

    public CheckoutCompletePage finish() {
        click(FINISH);
        return new CheckoutCompletePage(driver).waitUntilLoaded();
    }

    public InventoryPage cancel() {
        click(CANCEL);
        return new InventoryPage(driver).waitUntilLoaded();
    }
}
