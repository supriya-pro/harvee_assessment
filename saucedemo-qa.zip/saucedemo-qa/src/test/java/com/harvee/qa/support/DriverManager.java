package com.harvee.qa.support;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

/** Creates one browser per test and keeps it in a ThreadLocal so listeners can reach it. */
public final class DriverManager {

    private static final ThreadLocal<WebDriver> DRIVER = new ThreadLocal<>();

    private DriverManager() {
    }

    public static WebDriver start() {
        WebDriver driver;
        switch (Config.browser()) {
            case "firefox" -> {
                FirefoxOptions options = new FirefoxOptions();
                if (Config.headless()) {
                    options.addArguments("-headless");
                }
                driver = new FirefoxDriver(options);
            }
            case "edge" -> {
                EdgeOptions options = new EdgeOptions();
                if (Config.headless()) {
                    options.addArguments("--headless=new");
                }
                options.addArguments("--window-size=1280,900");
                driver = new EdgeDriver(options);
            }
            default -> {
                ChromeOptions options = new ChromeOptions();
                if (Config.headless()) {
                    options.addArguments("--headless=new");
                }
                options.addArguments("--window-size=1280,900", "--no-sandbox", "--disable-dev-shm-usage");
                // Keeps Chrome's password-leak popup from covering the page after login.
                options.addArguments("--disable-features=PasswordLeakDetection,PasswordManagerOnboarding");
                options.setExperimentalOption("prefs", java.util.Map.of(
                        "credentials_enable_service", false,
                        "profile.password_manager_enabled", false,
                        "profile.password_manager_leak_detection", false));
                driver = new ChromeDriver(options);
            }
        }
        // Implicit wait is left at 0 on purpose: all waiting is explicit (see BasePage).
        DRIVER.set(driver);
        return driver;
    }

    public static WebDriver get() {
        return DRIVER.get();
    }

    public static void stop() {
        WebDriver driver = DRIVER.get();
        if (driver != null) {
            driver.quit();
            DRIVER.remove();
        }
    }
}
