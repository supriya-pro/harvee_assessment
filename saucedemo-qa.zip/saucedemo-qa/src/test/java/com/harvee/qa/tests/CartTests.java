package com.harvee.qa.tests;

import com.harvee.qa.pages.CartPage;
import com.harvee.qa.pages.InventoryPage;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

public class CartTests extends BaseTest {

    @Test(description = "TC08 add two items, remove one: badge and cart contents match")
    public void tc08_addTwoItemsAndRemoveOne() {
        InventoryPage inventory = loginAsStandardUser();

        inventory.addToCart(BACKPACK).addToCart(BIKE_LIGHT);
        Assert.assertEquals(inventory.cartBadgeCount(), 2, "Badge after adding two items");

        inventory.removeFromCart(BIKE_LIGHT);
        Assert.assertEquals(inventory.cartBadgeCount(), 1, "Badge after removing one item");

        CartPage cart = inventory.openCart();
        Assert.assertEquals(cart.itemNames(), List.of(BACKPACK), "Cart should hold only the remaining item");
        Assert.assertEquals(cart.cartBadgeCount(), 1, "Badge on the cart page");
    }

    @Test(description = "TC09 remove an item from the cart page")
    public void tc09_removeItemFromCartPage() {
        InventoryPage inventory = loginAsStandardUser();
        inventory.addToCart(BACKPACK).addToCart(BIKE_LIGHT);

        CartPage cart = inventory.openCart().remove(BACKPACK);

        Assert.assertEquals(cart.itemNames(), List.of(BIKE_LIGHT));
        Assert.assertEquals(cart.cartBadgeCount(), 1);
    }

    @Test(description = "TC10 badge disappears when the cart becomes empty")
    public void tc10_badgeHiddenWhenCartEmpty() {
        InventoryPage inventory = loginAsStandardUser();
        Assert.assertFalse(inventory.isCartBadgeVisible(), "No badge expected with an empty cart");

        inventory.addToCart(BACKPACK);
        Assert.assertEquals(inventory.cartBadgeCount(), 1);

        inventory.removeFromCart(BACKPACK);
        Assert.assertFalse(inventory.isCartBadgeVisible(), "Badge should be hidden at zero items");
    }
}
