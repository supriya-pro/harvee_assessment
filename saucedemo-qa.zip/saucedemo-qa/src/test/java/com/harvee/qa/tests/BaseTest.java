package com.harvee.qa.tests;

import com.harvee.qa.pages.InventoryPage;
import com.harvee.qa.pages.LoginPage;
import com.harvee.qa.support.Config;
import com.harvee.qa.support.DriverManager;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

/** Each test gets its own fresh browser, so tests do not share state and can run in any order. */
public abstract class BaseTest {

    protected static final String BACKPACK = "Sauce Labs Backpack";
    protected static final String BIKE_LIGHT = "Sauce Labs Bike Light";

    protected WebDriver driver;

    @BeforeMethod(alwaysRun = true)
    public void setUp() {
        driver = DriverManager.start();
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown() {
        DriverManager.stop();
    }

    protected LoginPage openLoginPage() {
        return new LoginPage(driver).open();
    }

    protected InventoryPage loginAsStandardUser() {
        return openLoginPage().loginAs(Config.standardUser(), Config.password());
    }
}
