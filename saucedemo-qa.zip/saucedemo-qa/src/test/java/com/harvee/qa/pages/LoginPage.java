package com.harvee.qa.pages;

import com.harvee.qa.support.Config;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage extends BasePage {

    private static final By USERNAME = By.id("user-name");
    private static final By PASSWORD = By.id("password");
    private static final By LOGIN_BUTTON = By.id("login-button");
    private static final By ERROR = By.cssSelector("[data-test='error']");

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    public LoginPage open() {
        driver.get(Config.baseUrl() + "/");
        visible(LOGIN_BUTTON);
        return this;
    }

    public InventoryPage loginAs(String username, String password) {
        submit(username, password);
        return new InventoryPage(driver).waitUntilLoaded();
    }

    /** Submits the form without assuming it will succeed. */
    public LoginPage submit(String username, String password) {
        type(USERNAME, username);
        type(PASSWORD, password);
        click(LOGIN_BUTTON);
        return this;
    }

    /** Clicks Login with both fields left empty. */
    public LoginPage submitEmpty() {
        click(LOGIN_BUTTON);
        return this;
    }

    public String errorMessage() {
        return text(ERROR);
    }

    public boolean isDisplayed() {
        return isPresent(LOGIN_BUTTON);
    }
}
