package com.harvee.qa.tests;

import com.harvee.qa.pages.CartPage;
import com.harvee.qa.pages.CheckoutCompletePage;
import com.harvee.qa.pages.CheckoutInfoPage;
import com.harvee.qa.pages.CheckoutOverviewPage;
import com.harvee.qa.pages.InventoryPage;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.math.BigDecimal;

public class CheckoutTests extends BaseTest {

    @Test(description = "TC12 full checkout: total = item total + tax, order placed, cart empty")
    public void tc12_fullCheckoutWithCorrectTotals() {
        InventoryPage inventory = loginAsStandardUser();
        inventory.addToCart(BACKPACK).addToCart(BIKE_LIGHT);

        CheckoutOverviewPage overview = inventory.openCart().checkout()
                .fill("Ada", "Lovelace", "12345")
                .continueToOverview();

        BigDecimal itemTotal = overview.itemTotal();
        BigDecimal tax = overview.tax();
        BigDecimal total = overview.total();
        Assert.assertEquals(total, itemTotal.add(tax), "Total must equal item total plus tax");
        Assert.assertTrue(tax.signum() > 0, "Tax should be charged");

        CheckoutCompletePage complete = overview.finish();
        Assert.assertTrue(complete.confirmationHeader().toLowerCase().contains("thank you"),
                "Order confirmation expected but was: " + complete.confirmationHeader());
        Assert.assertFalse(complete.isCartBadgeVisible(), "Cart badge should be gone after the order");

        CartPage cart = complete.backToProducts().openCart();
        Assert.assertTrue(cart.itemNames().isEmpty(), "Cart should be empty after finishing: " + cart.itemNames());
    }

    @DataProvider(name = "missingFields")
    public Object[][] missingFields() {
        return new Object[][]{
                {"TC13 missing first name", "", "Lovelace", "12345", "First Name is required"},
                {"TC14 missing last name", "Ada", "", "12345", "Last Name is required"},
                {"TC15 missing postal code", "Ada", "Lovelace", "", "Postal Code is required"}
        };
    }

    @Test(dataProvider = "missingFields",
            description = "TC13/TC14/TC15 each missing checkout field shows its own error")
    public void tc13_tc14_tc15_missingCheckoutFieldsShowErrors(
            String caseName, String first, String last, String postal, String expectedError) {
        InventoryPage inventory = loginAsStandardUser();
        inventory.addToCart(BACKPACK);

        CheckoutInfoPage info = inventory.openCart().checkout()
                .fill(first, last, postal)
                .continueExpectingError();

        Assert.assertTrue(info.errorMessage().contains(expectedError),
                caseName + ": unexpected error: " + info.errorMessage());
        Assert.assertEquals(info.currentPath(), CheckoutInfoPage.PATH, "User must stay on step one");
    }

    @Test(description = "TC17 cancel on the overview returns to products without placing the order")
    public void tc17_cancelKeepsCartAndPlacesNoOrder() {
        InventoryPage inventory = loginAsStandardUser();
        inventory.addToCart(BACKPACK);

        InventoryPage afterCancel = inventory.openCart().checkout()
                .fill("Ada", "Lovelace", "12345")
                .continueToOverview()
                .cancel();

        Assert.assertEquals(afterCancel.currentPath(), InventoryPage.PATH);
        Assert.assertEquals(afterCancel.cartBadgeCount(), 1, "Item should still be in the cart");
    }
}
