package com.harvee.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CheckoutCompletePage extends BasePage {

    public static final String PATH = "/checkout-complete.html";

    private static final By HEADER = By.cssSelector("[data-test='complete-header']");
    private static final By BACK_HOME = By.id("back-to-products");
    private static final By CART_BADGE = By.cssSelector("[data-test='shopping-cart-badge']");

    public CheckoutCompletePage(WebDriver driver) {
        super(driver);
    }

    public CheckoutCompletePage waitUntilLoaded() {
        visible(HEADER);
        waitForPath(PATH);
        return this;
    }

    public String confirmationHeader() {
        return text(HEADER);
    }

    public boolean isCartBadgeVisible() {
        return isPresent(CART_BADGE);
    }

    public InventoryPage backToProducts() {
        click(BACK_HOME);
        return new InventoryPage(driver).waitUntilLoaded();
    }
}
