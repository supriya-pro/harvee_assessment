package com.harvee.qa.pages;

import com.harvee.qa.support.Config;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

public class InventoryPage extends BasePage {

    public static final String PATH = "/inventory.html";

    private static final By TITLE = By.cssSelector("[data-test='title']");
    private static final By ITEM = By.cssSelector("[data-test='inventory-item']");
    private static final By ITEM_NAME = By.cssSelector("[data-test='inventory-item-name']");
    private static final By ITEM_PRICE = By.cssSelector("[data-test='inventory-item-price']");
    private static final By SORT = By.cssSelector("[data-test='product-sort-container']");
    private static final By CART_LINK = By.cssSelector("[data-test='shopping-cart-link']");
    private static final By CART_BADGE = By.cssSelector("[data-test='shopping-cart-badge']");
    private static final By MENU_BUTTON = By.id("react-burger-menu-btn");
    private static final By LOGOUT_LINK = By.id("logout_sidebar_link");

    public InventoryPage(WebDriver driver) {
        super(driver);
    }

    public InventoryPage waitUntilLoaded() {
        visible(TITLE);
        waitForPath(PATH);
        return this;
    }

    public InventoryPage openDirectly() {
        driver.get(Config.baseUrl() + PATH);
        return this;
    }

    public String title() {
        return text(TITLE);
    }

    public int itemCount() {
        return all(ITEM).size();
    }

    public List<String> itemNames() {
        return all(ITEM_NAME).stream().map(WebElement::getText).collect(Collectors.toList());
    }

    public List<BigDecimal> itemPrices() {
        return all(ITEM_PRICE).stream()
                .map(e -> new BigDecimal(e.getText().replace("$", "").trim()))
                .collect(Collectors.toList());
    }

    /** Sort options by visible text: "Name (A to Z)", "Name (Z to A)", "Price (low to high)", "Price (high to low)". */
    public InventoryPage sortBy(String visibleText) {
        new Select(visible(SORT)).selectByVisibleText(visibleText);
        return this;
    }

    private By addButtonFor(String itemName) {
        String id = "add-to-cart-" + itemName.toLowerCase().replace(' ', '-');
        return By.id(id);
    }

    private By removeButtonFor(String itemName) {
        String id = "remove-" + itemName.toLowerCase().replace(' ', '-');
        return By.id(id);
    }

    public InventoryPage addToCart(String itemName) {
        click(addButtonFor(itemName));
        visible(removeButtonFor(itemName));
        return this;
    }

    public InventoryPage removeFromCart(String itemName) {
        click(removeButtonFor(itemName));
        visible(addButtonFor(itemName));
        return this;
    }

    /** Returns 0 when the badge is not shown. */
    public int cartBadgeCount() {
        List<WebElement> badge = all(CART_BADGE);
        return badge.isEmpty() ? 0 : Integer.parseInt(badge.get(0).getText());
    }

    public boolean isCartBadgeVisible() {
        return isPresent(CART_BADGE);
    }

    public CartPage openCart() {
        click(CART_LINK);
        return new CartPage(driver).waitUntilLoaded();
    }

    public LoginPage logout() {
        click(MENU_BUTTON);
        click(LOGOUT_LINK);
        LoginPage login = new LoginPage(driver);
        wait.until(d -> login.isDisplayed());
        return login;
    }
}
