package com.harvee.qa.support;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/** Saves a PNG to target/screenshots when a test fails. */
public class TestListener implements ITestListener {

    @Override
    public void onTestFailure(ITestResult result) {
        WebDriver driver = DriverManager.get();
        if (!(driver instanceof TakesScreenshot)) {
            return;
        }
        try {
            byte[] png = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
            Path dir = Paths.get("target", "screenshots");
            Files.createDirectories(dir);
            String name = result.getMethod().getMethodName();
            Object[] params = result.getParameters();
            if (params != null && params.length > 0) {
                name += "_" + String.valueOf(params[0]).replaceAll("[^A-Za-z0-9]", "_");
            }
            Path file = dir.resolve(name + ".png");
            Files.write(file, png);
            System.out.println("Screenshot saved: " + file.toAbsolutePath());
        } catch (IOException | RuntimeException e) {
            System.out.println("Could not save screenshot: " + e.getMessage());
        }
    }
}
