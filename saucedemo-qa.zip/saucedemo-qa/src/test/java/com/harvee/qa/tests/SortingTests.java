package com.harvee.qa.tests;

import com.harvee.qa.pages.InventoryPage;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SortingTests extends BaseTest {

    @Test(description = "TC05 sorts by price low to high")
    public void tc05_sortsByPriceLowToHigh() {
        InventoryPage inventory = loginAsStandardUser();

        inventory.sortBy("Price (low to high)");

        List<BigDecimal> prices = inventory.itemPrices();
        Assert.assertEquals(prices.size(), 6, "All products should be listed");
        List<BigDecimal> expected = new ArrayList<>(prices);
        Collections.sort(expected);
        Assert.assertEquals(prices, expected, "The whole list must be in ascending price order");
    }

    @Test(description = "TC06 sorts by price high to low")
    public void tc06_sortsByPriceHighToLow() {
        InventoryPage inventory = loginAsStandardUser();

        inventory.sortBy("Price (high to low)");

        List<BigDecimal> prices = inventory.itemPrices();
        List<BigDecimal> expected = new ArrayList<>(prices);
        expected.sort(Collections.reverseOrder());
        Assert.assertEquals(prices, expected, "The whole list must be in descending price order");
    }

    @Test(description = "TC07 sorts by name A to Z and Z to A")
    public void tc07_sortsByName() {
        InventoryPage inventory = loginAsStandardUser();

        inventory.sortBy("Name (A to Z)");
        List<String> az = inventory.itemNames();
        List<String> expectedAz = new ArrayList<>(az);
        Collections.sort(expectedAz);
        Assert.assertEquals(az, expectedAz, "A to Z order");

        inventory.sortBy("Name (Z to A)");
        List<String> za = inventory.itemNames();
        List<String> expectedZa = new ArrayList<>(za);
        expectedZa.sort(Collections.reverseOrder());
        Assert.assertEquals(za, expectedZa, "Z to A order");
    }
}
