package com.harvee.qa.support;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Reads settings in this order: -D system property, environment variable, config.properties.
 * Nothing environment-specific is hard-coded in the tests.
 */
public final class Config {

    private static final Properties FILE = new Properties();

    static {
        try (InputStream in = Config.class.getClassLoader().getResourceAsStream("config.properties")) {
            if (in != null) {
                FILE.load(in);
            }
        } catch (IOException e) {
            throw new IllegalStateException("Cannot read config.properties", e);
        }
    }

    private Config() {
    }

    private static String get(String key, String envName) {
        String value = System.getProperty(key);
        if (value == null || value.isBlank()) {
            value = System.getenv(envName);
        }
        if (value == null || value.isBlank()) {
            value = FILE.getProperty(key);
        }
        if (value == null) {
            throw new IllegalStateException("Missing config value: " + key);
        }
        return value;
    }

    public static String baseUrl() {
        String url = get("baseUrl", "BASE_URL");
        return url.endsWith("/") ? url.substring(0, url.length() - 1) : url;
    }

    public static String browser() {
        return get("browser", "BROWSER").toLowerCase();
    }

    public static boolean headless() {
        return Boolean.parseBoolean(get("headless", "HEADLESS"));
    }

    public static String standardUser() {
        return get("standardUser", "STANDARD_USER");
    }

    public static String lockedUser() {
        return get("lockedUser", "LOCKED_USER");
    }

    public static String password() {
        return get("password", "PASSWORD");
    }
}
