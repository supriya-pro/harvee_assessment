# AI usage log

I used Claude (Anthropic) as a coding assistant for this assessment. The table lists each place, what I asked for, and what I checked or changed. Fill in the "My own checks" column from what you actually did before submitting.

| # | Where | What I asked for | What I changed or verified |
|---|-------|------------------|----------------------------|
| 1 | `docs/MANUAL_TESTS.md` | Draft of questions, 24 test cases, exploratory charter and strategy from the assessment brief. | Reviewed each case against the business rules; kept the strategy under 150 words; set Automate Yes/No so it matches the README traceability table. |
| 2 | `pom.xml`, `testng.xml`, `config.properties` | Maven project with Selenium 4, TestNG, HTML and JUnit XML reports, config from properties or environment. | Removed a pom block that would have passed unresolved `${...}` values into config; confirmed `-D` properties reach the test JVM. |
| 3 | `pages/*` | Page objects for login, products, cart, checkout steps. | Locators use `data-test` attributes and ids; all waits are explicit; no locators in tests. Verify against the live site on first run. |
| 4 | `tests/*` | Tests named with manual case IDs, covering every item required in A2. | Replaced a placeholder check in TC12 that did not test anything; changed TC02/TC19 to assert message content and stay on the login page. |
| 5 | `support/TestListener.java` | Screenshot on failure. | Checked output path `target/screenshots` and handling of parameterized test names. |
| 6 | `README.md` | Run instructions, traceability table, 200-test growth paragraph. | Corrected counts (17 of 24 cases automated, 14 test methods, 5 data rows). |
| 7 | `ANSWERS.md` B1–B4 | Review of the AI-written test, evaluation checks, defect report, client message. | Checked B4 is under 150 words; kept the recommendation with a practical alternative. |

## How I checked the output

- Run `mvn test-compile` and fix any compile errors (it could not be compiled in the authoring environment because Maven Central was not reachable). Read the generated locators against the site's markup.
- Run `mvn test` against the public site and review the HTML report and any screenshots. (Not run from the authoring environment; do this before submitting.)
- For key tests, make one assertion wrong on purpose and confirm the test fails.
